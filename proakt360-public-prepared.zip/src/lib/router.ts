"use client";

// Мини hash-роутер прототипа: единственный маршрут Next.js «/»,
// вся навигация — по якорям (#/objects/3, #/estimates/5?new=1 …).

import { useCallback, useEffect, useState } from "react";

export type Route = {
  path: string; // "/objects/3"
  segments: string[]; // ["objects", "3"]
  query: URLSearchParams;
  hash: string; // полный "#/objects/3?x=1"
};

function parse(hash: string): Route {
  const raw = hash.replace(/^#\/?/, "");
  const [pathPart, queryPart] = raw.split("?");
  const segments = pathPart.split("/").filter(Boolean).map(decodeURIComponent);
  return {
    path: "/" + segments.join("/"),
    segments,
    query: new URLSearchParams(queryPart ?? ""),
    hash,
  };
}

export function useRoute(): Route & { navigate: (to: string) => void } {
  const [route, setRoute] = useState<Route>(() =>
    typeof window === "undefined" ? parse("#/") : parse(window.location.hash || "#/"),
  );

  useEffect(() => {
    const onChange = () => setRoute(parse(window.location.hash || "#/"));
    window.addEventListener("hashchange", onChange);
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  const navigate = useCallback((to: string) => {
    const next = to.startsWith("#") ? to : `#${to.startsWith("/") ? to : `/${to}`}`;
    if (window.location.hash === next) return;
    window.location.hash = next;
  }, []);

  return { ...route, navigate };
}

export function navigate(to: string) {
  const next = to.startsWith("#") ? to : `#${to.startsWith("/") ? to : `/${to}`}`;
  window.location.hash = next;
}
