// GET /api/auth/me — состояние входа: {authRequired, authed, lang, masterName, companyName}.

import { NextResponse } from 'next/server'
import { getSessionUser, getSettings } from '@/db/auth'

export const dynamic = 'force-dynamic'

export async function GET() {
  const [{ authed, required }, s] = await Promise.all([getSessionUser(), getSettings()])
  return NextResponse.json({
    authRequired: required,
    authed,
    lang: s.lang,
    masterName: s.masterName,
    companyName: s.companyName,
  })
}
