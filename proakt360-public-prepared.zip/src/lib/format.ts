// Форматирование для «ПрорАКТ 360»: деньги (грн), даты, множественные числа.

const NBSP = "\u202F"; // узкий пробел — как в живых сметах мастера

export function money(v: number): string {
  const rounded = Math.round(v * 100) / 100;
  const int = Math.trunc(rounded);
  const frac = Math.round((rounded - int) * 100);
  const s = Math.abs(int)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, NBSP);
  const sign = rounded < 0 ? "−" : "";
  return `${sign}${s}${frac > 0 ? "," + String(frac).padStart(2, "0") : ""}${NBSP}грн`;
}

/** Короткие деньги для дашборда: 126 400 грн → «126,4 тыс». */
export function moneyShort(v: number): string {
  const abs = Math.abs(v);
  if (abs >= 1_000_000) return `${(v / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1).replace(".", ",")}${NBSP}млн`;
  if (abs >= 10_000) return `${(v / 1000).toFixed(0)}${NBSP}тыс`;
  if (abs >= 1000) return `${(v / 1000).toFixed(1).replace(".", ",")}${NBSP}тыс`;
  return Math.round(v).toString();
}

export function plural(n: number, one: string, few: string, many: string): string {
  const abs = Math.abs(n) % 100;
  const d = abs % 10;
  if (abs > 10 && abs < 20) return many;
  if (d === 1) return one;
  if (d >= 2 && d <= 4) return few;
  return many;
}

export function qty(v: number): string {
  const rounded = Math.round(v * 100) / 100;
  return rounded.toString().replace(".", ",");
}

const MONTHS_SHORT = ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"];
const MONTHS_FULL = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];

export function dateShort(iso: string): string {
  const d = new Date(iso);
  return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
}

export function dateFull(iso: string): string {
  const d = new Date(iso);
  return `${d.getDate()} ${MONTHS_FULL[d.getMonth()]} ${d.getFullYear()}`;
}

export function dateTime(iso: string): string {
  const d = new Date(iso);
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${dateShort(iso)}, ${hh}:${mm}`;
}

/** «через 21 день» / «5 дней назад» для дедлайнов */
export function daysLeft(iso: string): { text: string; overdue: boolean; days: number } {
  const days = Math.round((new Date(iso).getTime() - Date.now()) / 86400000);
  if (days === 0) return { text: "сегодня", overdue: false, days: 0 };
  if (days > 0) {
    return { text: `через ${days} ${plural(days, "день", "дня", "дней")}`, overdue: false, days };
  }
  return { text: `${-days} ${plural(-days, "день", "дня", "дней")} назад`, overdue: true, days };
}

export const EST_STATUS: Record<string, { label: string; tone: "draft" | "sent" | "approved" | "done" }> = {
  draft: { label: "Черновик", tone: "draft" },
  sent: { label: "У заказчика", tone: "sent" },
  approved: { label: "Согласована", tone: "approved" },
  done: { label: "Закрыта", tone: "done" },
};

export const ACT_STATUS: Record<string, { label: string }> = {
  paid: { label: "Оплачен" },
  partial: { label: "Частично" },
  unpaid: { label: "Ждёт оплаты" },
  zero: { label: "Без суммы" },
};

export const OBJECT_STATUS: Record<string, string> = {
  active: "В работе",
  paused: "Пауза",
  done: "Завершён",
};

export const STAGE_STATUS: Record<string, { label: string }> = {
  done: { label: "Готово" },
  current: { label: "Сейчас" },
  next: { label: "Далее" },
  todo: { label: "Впереди" },
};
