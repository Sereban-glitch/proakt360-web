import { db } from "@/lib/db";
import { createHash, randomBytes, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";

// ---------------------------------------------------------------------------
// Аутентификация мастера: локальный пароль (sha256 соль+пароль) + сессии
// в SQLite. Никаких внешних сервисов, OAuth и ключей.
// Если пароль не установлен (passHash = "") — вход не требуется (демо-режим).
// ---------------------------------------------------------------------------

export const SESSION_COOKIE = "proakt360_session";
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 дней

export function sha256(s: string): string {
  return createHash("sha256").update(s, "utf8").digest("hex");
}

export async function getSettings() {
  let s = await db.appSettings.findUnique({ where: { id: 1 } });
  if (!s) {
    s = await db.appSettings.create({ data: { id: 1 } });
  }
  return s;
}

export function isAuthRequired(passHash: string): boolean {
  return passHash.trim().length > 0;
}

export async function setPassword(newPassword: string): Promise<void> {
  const salt = randomBytes(16).toString("hex");
  const hash = sha256(salt + newPassword);
  await db.appSettings.update({ where: { id: 1 }, data: { passSalt: salt, passHash: hash } });
  // смена пароля аннулирует все сессии
  await db.session.deleteMany({});
}

export async function verifyPassword(input: string): Promise<boolean> {
  const s = await getSettings();
  if (!isAuthRequired(s.passHash)) return true;
  const expect = Buffer.from(s.passHash, "hex");
  const got = Buffer.from(sha256(s.passSalt + input), "hex");
  if (expect.length !== got.length) return false;
  return timingSafeEqual(expect, got);
}

export async function createSession(): Promise<string> {
  const token = randomBytes(32).toString("hex");
  await db.session.create({
    data: {
      token,
      appSettingsId: 1,
      expiresAt: new Date(Date.now() + SESSION_TTL_MS),
    },
  });
  return token;
}

export async function getSessionUser(): Promise<{ authed: boolean; required: boolean }> {
  const s = await getSettings();
  const required = isAuthRequired(s.passHash);
  if (!required) return { authed: true, required: false };
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return { authed: false, required: true };
  const session = await db.session.findUnique({ where: { token } });
  if (!session) return { authed: false, required: true };
  if (session.expiresAt.getTime() < Date.now()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => undefined);
    return { authed: false, required: true };
  }
  return { authed: true, required: true };
}

export async function dropSession(token: string): Promise<void> {
  await db.session.deleteMany({ where: { token } });
}

// Разрешение токена клиентского доступа: это может быть
// 1) clientToken объекта → кабинет объекта,
// 2) shareToken сметы → кабинет объекта этой сметы,
// 3) token акта → кабинет объекта этого акта.
// Так «прямые ссылки» из сметы и акта открывают один и тот же кабинет.
export async function resolveClientToken(
  token: string,
): Promise<
  | { ok: true; objectId: number; kind: "object" | "estimate" | "act"; refId?: number }
  | { ok: false }
> {
  const obj = await db.buildObject.findUnique({ where: { clientToken: token } });
  if (obj) return { ok: true, objectId: obj.id, kind: "object" };
  const est = await db.estimate.findUnique({
    where: { shareToken: token },
    select: { id: true, objectId: true },
  });
  if (est) return { ok: true, objectId: est.objectId, kind: "estimate", refId: est.id };
  const act = await db.act.findUnique({
    where: { token: token },
    select: { id: true, objectId: true },
  });
  if (act) return { ok: true, objectId: act.objectId, kind: "act", refId: act.id };
  return { ok: false };
}
