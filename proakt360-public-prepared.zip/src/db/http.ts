// Мелкие хелперы для API-роутов: JSON-ответы, разбор тел, валидация чисел.

import { NextResponse } from 'next/server'
import { getSessionUser } from './auth'

export function jsonError(status: number, message: string): NextResponse {
  return NextResponse.json({ error: message }, { status })
}

export function badRequest(message: string): NextResponse {
  return jsonError(400, message)
}

export function notFound(message = 'Не найдено'): NextResponse {
  return jsonError(404, message)
}

export function readBody(req: Request): Promise<Record<string, unknown> | null> {
  return req
    .json()
    .then((v) => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : null))
    .catch(() => null)
}

/** Число из JSON (строки «12,5» тоже понимаем); null — не число. */
export function asNumber(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v.trim().replace(',', '.'))
    return Number.isFinite(n) ? n : null
  }
  return null
}

export function asString(v: unknown): string | null {
  return typeof v === 'string' ? v : null
}

export function asBool(v: unknown): boolean | null {
  if (typeof v === 'boolean') return v
  if (v === 'true') return true
  if (v === 'false') return false
  return null
}

/** Позитивный целый id из сегмента пути; null — некорректный. */
export function parseId(raw: string | undefined): number | null {
  if (!raw) return null
  const n = Number(raw)
  return Number.isInteger(n) && n > 0 ? n : null
}

/**
 * Guard для мастерских роутов: если установлен пароль — требуем сессию.
 * Возвращает NextResponse 401, если доступ запрещён; null — если доступ разрешён.
 */
export async function requireMaster(): Promise<NextResponse | null> {
  const { authed, required } = await getSessionUser()
  if (required && !authed) {
    return jsonError(401, 'Требуется вход мастера')
  }
  return null
}
