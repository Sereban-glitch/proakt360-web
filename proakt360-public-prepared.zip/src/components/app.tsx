"use client";

// Корень SPA «ПрорАКТ 360» v2: провайдеры, вход мастера (auth-гейт),
// маршрутизация по hash. Прямая загрузка «/» нормализуется в «#/» —
// refresh и прямые ссылки работают без «пустого» экрана.

import * as React from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "next-themes";
import { motion } from "framer-motion";
import { useRoute } from "@/lib/router";
import { useI18n } from "@/lib/i18n";
import { api, ApiError } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { DashboardView } from "@/views/dashboard";
import { ObjectsView } from "@/views/objects";
import { ObjectDetailView } from "@/views/object-detail";
import { EstimatesView } from "@/views/estimates";
import { EstimateDetailView } from "@/views/estimate-detail";
import { ActsView } from "@/views/acts";
import { ActDetailView } from "@/views/act-detail";
import { PriceView } from "@/views/price";
import { TemplatesView } from "@/views/templates";
import { ReportView } from "@/views/report";
import { SettingsView } from "@/views/settings";
import { LoginView } from "@/views/login";
import { ClientCabinetView } from "@/views/client";
import { ShowcaseView } from "@/views/showcase";
import { Empty, ListSkeleton, BrandMark } from "@/components/kit";
import { Button } from "@/components/ui/button";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 10_000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Screen({ routeKey, children }: { routeKey: string; children: React.ReactNode }) {
  return (
    <motion.div
      key={routeKey}
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.18, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

/** Нормализация: пустой hash «» → «#/». После неё refresh/прямая ссылка стабильны. */
function useNormalizedHash() {
  React.useEffect(() => {
    if (!window.location.hash || window.location.hash === "#") {
      window.history.replaceState(null, "", window.location.pathname + window.location.search + "#/");
      window.dispatchEvent(new HashChangeEvent("hashchange"));
    }
  }, []);
}

function View() {
  const route = useRoute();
  useNormalizedHash();
  const [a, b] = route.segments;
  const id = Number(b);
  const { lang } = useI18n();

  // --- отдельные «публичные» экраны без шелла мастера ---
  if (a === "client" || a === "c") {
    return <ClientCabinetView token={b ?? ""} />;
  }
  if (a === "showcase") {
    return <ShowcaseView />;
  }

  // --- кабинет мастера ---
  let content: React.ReactNode;
  if (!a) content = <DashboardView />;
  else if (a === "objects") content = b ? <ObjectDetailView id={id} /> : <ObjectsView />;
  else if (a === "estimates") content = b ? <EstimateDetailView id={id} /> : <EstimatesView />;
  else if (a === "acts") content = b ? <ActDetailView id={id} /> : <ActsView />;
  else if (a === "price") content = <PriceView />;
  else if (a === "templates") content = <TemplatesView />;
  else if (a === "report") content = <ReportView />;
  else if (a === "settings") content = <SettingsView />;
  else
    content = (
      <Empty
        title={lang === "uk" ? "Екран не знайдено" : "Экран не найден"}
        sub={`${lang === "uk" ? "Маршрут" : "Маршрут"} «${route.path}» ${lang === "uk" ? "не існує. Поверніться на робочий стіл." : "не существует. Вернитесь на рабочий стол."}`}
      />
    );

  return (
    <AppShell current={route.path}>
      <Screen routeKey={route.path}>{content}</Screen>
    </AppShell>
  );
}

/** Auth-гейт: если пароль установлен и нет сессии — экран входа. */
function AuthGate({ children }: { children: React.ReactNode }) {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ["me"],
    queryFn: () => api.me(),
    staleTime: 5_000,
  });
  const { setLang } = useI18n();
  const langRef = React.useRef("");

  // язык по умолчанию подтягиваем из настроек сервера (один раз)
  React.useEffect(() => {
    if (data?.lang && langRef.current === "") {
      langRef.current = data.lang;
      const stored = window.localStorage.getItem("proakt360-lang");
      if (!stored) setLang(data.lang);
    }
  }, [data?.lang, setLang]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-background">
        <BrandMark size={44} />
        <ListSkeleton rows={3} />
      </div>
    );
  }
  if (error) {
    const msg = error instanceof ApiError ? error.message : "Сервер недоступен";
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-background px-6 text-center">
        <BrandMark size={44} />
        <p className="text-sm text-muted-foreground max-w-sm">{msg}</p>
        <Button onClick={() => refetch()}>Повторить</Button>
      </div>
    );
  }
  if (data?.authRequired && !data.authed) {
    return <LoginView onDone={() => refetch()} />;
  }
  return <>{children}</>;
}

export function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <QueryClientProvider client={queryClient}>
        <AuthGate>
          <View />
        </AuthGate>
      </QueryClientProvider>
    </ThemeProvider>
  );
}
