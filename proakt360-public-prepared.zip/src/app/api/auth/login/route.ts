// POST /api/auth/login {password} → HttpOnly cookie сессии (30 дней).

import { NextResponse } from 'next/server'
import { verifyPassword, createSession, getSettings, SESSION_COOKIE } from '@/db/auth'
import { badRequest, readBody } from '@/db/http'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  const body = await readBody(req)
  const password = typeof body?.password === 'string' ? body.password : ''
  if (password.length === 0) return badRequest('Введите пароль')

  const settings = await getSettings()
  if (!settings.passHash) {
    return NextResponse.json({ ok: true, authRequired: false })
  }
  const valid = await verifyPassword(password)
  if (!valid) {
    // задержка против перебора
    await new Promise((r) => setTimeout(r, 400))
    return NextResponse.json({ error: 'Неверный пароль' }, { status: 401 })
  }
  const token = await createSession()
  const res = NextResponse.json({ ok: true, authRequired: true })
  res.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 30 * 24 * 60 * 60,
  })
  return res
}
